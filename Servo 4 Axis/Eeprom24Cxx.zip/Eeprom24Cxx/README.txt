https://github.com/NickChungVietNam/ALL_EEPROM_24Cxx_ATMEL_ARDUINO_AT_MASTER
Đây là thư viện dùng để lưu các số vào các loại ic EEPROM atmel 24cxx với arduino.
Tác giả: Thái Sơn 